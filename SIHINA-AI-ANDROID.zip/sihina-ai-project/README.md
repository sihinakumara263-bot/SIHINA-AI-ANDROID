# SIHINA AI — Sinhala Voice Assistant

Android starter app for a Sinhala voice assistant.

- Sinhala speech input via Android SpeechRecognizer.
- Conversation-style screen.
- Text-to-speech reply if the phone's installed TTS engine supports Sinhala.
- Optional HTTPS AI backend endpoint configured with Gradle property AI_API_URL.
- GitHub Actions workflow builds a debug APK artifact.

## Build APK on GitHub
Open Actions → Build SIHINA AI APK → Run workflow. When it finishes, download the SIHINA-AI-debug-APK artifact.

## AI backend
No AI provider key is embedded in this APK. Configure a secure HTTPS backend accepting JSON {"message":"..."} and returning {"answer":"..."}, then build with Gradle property AI_API_URL=https://your-backend.example/ask.

This starter app does not provide real AI-generated answers until a backend is configured. Speech recognition and Sinhala text-to-speech depend on services available on the phone.
