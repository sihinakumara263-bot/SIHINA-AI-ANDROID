package com.sihina.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 101;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private TextView statusText, conversationText;
    private Button micButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen(); initTextToSpeech();
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { setStatus("අහගෙන ඉන්නවා… දැන් කතා කරන්න"); }
                @Override public void onBeginningOfSpeech() { setStatus("ඔයාගේ කටහඬ අහගෙන ඉන්නවා…"); }
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() { setStatus("ඔයා කියපු දේ සකස් කරනවා…"); }
                @Override public void onError(int e) { setStatus("හඬ හඳුනාගන්න බැරි වුණා. නැවත උත්සාහ කරන්න."); micButton.setEnabled(true); }
                @Override public void onResults(Bundle b) {
                    ArrayList<String> matches = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    micButton.setEnabled(true);
                    if (matches != null && !matches.isEmpty()) { String q = matches.get(0); appendMessage("ඔයා", q); askAssistant(q); }
                    else setStatus("කතාව හඳුනාගන්න බැරි වුණා.");
                }
                @Override public void onPartialResults(Bundle b) {}
                @Override public void onEvent(int event, Bundle b) {}
            });
        } else { setStatus("මෙම Phone එකේ Speech Recognition සේවාවක් හමු වුණේ නැහැ."); micButton.setEnabled(false); }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22)); root.setBackgroundColor(Color.rgb(10, 14, 30));
        TextView title = new TextView(this); title.setText("SIHINA AI"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView subtitle = new TextView(this); subtitle.setText("ඔයාගේ සිංහල AI සහායකයා"); subtitle.setTextColor(Color.rgb(166, 190, 255)); subtitle.setTextSize(16); subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(35)));
        TextView orb = new TextView(this); orb.setText("✦"); orb.setTextColor(Color.WHITE); orb.setTextSize(58); orb.setGravity(Gravity.CENTER); orb.setBackgroundColor(Color.rgb(45, 54, 110));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(118), dp(118)); op.gravity = Gravity.CENTER; op.topMargin = dp(22); op.bottomMargin = dp(16); root.addView(orb, op);
        statusText = new TextView(this); statusText.setText("කතා කරන්න Mic බොත්තම ඔබන්න"); statusText.setTextColor(Color.rgb(220, 226, 245)); statusText.setTextSize(15); statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, dp(48)));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); conversationText = new TextView(this);
        conversationText.setText("ආයුබෝවන්! මම SIHINA AI.\n\nමට සිංහලෙන් ප්‍රශ්නයක් අහන්න."); conversationText.setTextColor(Color.WHITE); conversationText.setTextSize(16); conversationText.setLineSpacing(dp(5), 1.0f); conversationText.setPadding(dp(15), dp(15), dp(15), dp(15)); conversationText.setBackgroundColor(Color.rgb(24, 30, 52)); scroll.addView(conversationText);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1f); sp.topMargin = dp(12); sp.bottomMargin = dp(16); root.addView(scroll, sp);
        micButton = new Button(this); micButton.setText("🎙  කතා කරන්න"); micButton.setTextSize(18); micButton.setAllCaps(false); micButton.setTextColor(Color.WHITE); micButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(77, 92, 220))); micButton.setOnClickListener(v -> startListening()); root.addView(micButton, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView note = new TextView(this); note.setText("අන්තර්ජාලය අවශ්‍යයි • AI සම්බන්ධතාවය ඊළඟ පියවරේදී සකසමු"); note.setTextColor(Color.rgb(150, 160, 190)); note.setTextSize(11); note.setGravity(Gravity.CENTER); root.addView(note, new LinearLayout.LayoutParams(-1, dp(34)));
        setContentView(root);
    }
    private void initTextToSpeech() { textToSpeech = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) { int r = textToSpeech.setLanguage(new Locale("si", "LK")); ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED; } }); }
    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO); return; }
        if (speechRecognizer == null) { Toast.makeText(this, "Speech Recognition සේවාව ලබාගත නොහැක.", Toast.LENGTH_LONG).show(); return; }
        try { Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "si-LK"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true); micButton.setEnabled(false); speechRecognizer.startListening(i); }
        catch (Exception e) { micButton.setEnabled(true); setStatus("Mic ආරම්භ කිරීමට බැරි වුණා."); }
    }
    private void askAssistant(String question) {
        if (BuildConfig.AI_API_URL == null || BuildConfig.AI_API_URL.trim().isEmpty()) { String a = "ඔයාගේ ප්‍රශ්නය ලැබුණා. AI පිළිතුරු ලබාදීම සක්‍රිය කිරීමට අපි ඊළඟ පියවරේදී ආරක්ෂිත AI සේවාවක් සම්බන්ධ කරමු."; appendMessage("SIHINA AI", a); speak(a); setStatus("AI සේවාව සම්බන්ධ කිරීමට සූදානම්."); return; }
        setStatus("AI හිතමින් ඉන්නවා…"); executor.execute(() -> { HttpURLConnection c = null; try {
            c = (HttpURLConnection) new URL(BuildConfig.AI_API_URL).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            JSONObject body = new JSONObject(); body.put("message", question); try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(); StringBuilder out = new StringBuilder(); try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) out.append(line); }
            if (code < 200 || code >= 300) throw new Exception("AI backend error"); String answer = new JSONObject(out.toString()).optString("answer", "මට දැන් පිළිතුරක් ලබාගන්න බැරි වුණා.");
            runOnUiThread(() -> { appendMessage("SIHINA AI", answer); speak(answer); setStatus("පිළිතුර සූදානම්."); });
        } catch (Exception e) { runOnUiThread(() -> { String a = "සමාවෙන්න, AI සේවාවට සම්බන්ධ වෙන්න බැරි වුණා. අන්තර්ජාලය සහ සේවා සැකසුම් පරීක්ෂා කරන්න."; appendMessage("SIHINA AI", a); speak(a); setStatus("සම්බන්ධතාවයේ දෝෂයක්."); }); }
        finally { if (c != null) c.disconnect(); } });
    }
    private void appendMessage(String who, String msg) { conversationText.append("\n\n" + who + ":\n" + msg); }
    private void speak(String text) { if (textToSpeech != null && ttsReady) textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sihina_reply"); }
    private void setStatus(String text) { runOnUiThread(() -> statusText.setText(text)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) { super.onRequestPermissionsResult(code, permissions, results); if (code == REQUEST_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening(); else if (code == REQUEST_AUDIO) setStatus("කතා කිරීමට Microphone අවසරය අවශ්‍යයි."); }
    @Override protected void onDestroy() { if (speechRecognizer != null) speechRecognizer.destroy(); if (textToSpeech != null) textToSpeech.shutdown(); executor.shutdownNow(); super.onDestroy(); }
}
